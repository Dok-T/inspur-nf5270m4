#!/bin/sh

# Set Variables 
XF86_LIB_DIR="/usr/lib64/xorg/modules"
XF86_DRV_DIR="/usr/lib/xorg/modules/drivers"
XF86_DRV_DIR1="/usr/lib64/xorg/modules/drivers"
XF86_DRV_DIR2="/usr/X11R6/lib64/modules/drivers"
cmd_sudo=""
test -e /usr/bin/sudo && cmd_sudo="sudo"

# Uninstall
if [ "$1" = "uninstall" ]; then
echo "ASPEED Graphics Family Linux XORG 7.2 driver uninstall begin ...."
$cmd_sudo rm -f $XF86_DRV_DIR/ast_drv.*

test -e $XF86_DRV_DIR2 && XF86_DRV_DIR=$XF86_DRV_DIR2
test -e $XF86_DRV_DIR1 && XF86_DRV_DIR=$XF86_DRV_DIR1

test -e ./backup/ast_drv.so && $cmd_sudo cp -f ./backup/ast_drv.*   $XF86_DRV_DIR/ast_drv.*

$cmd_sudo rm -rf ./backup
echo "ASPEED Graphics Family Linux XORG 7.2 driver Uninstall Finished"
exit 0
fi

# Install
echo "ASPEED Graphics Family Linux XORG 7.2 driver update begin ...."
$cmd_sudo rm -rf ./backup
$cmd_sudo mkdir ./backup

test -e $XF86_DRV_DIR2 && XF86_DRV_DIR=$XF86_DRV_DIR2
test -e $XF86_DRV_DIR1 && XF86_DRV_DIR=$XF86_DRV_DIR1

test -e $XF86_DRV_DIR/ast_drv.so && $cmd_sudo cp -f $XF86_DRV_DIR/ast_drv.* ./backup

$cmd_sudo rm -f $XF86_DRV_DIR/ast_drv.*

$cmd_sudo cp -f ast_drv.*   $XF86_DRV_DIR

echo "ASPEED Graphics Family Linux XORG 7.2 driver update finished"

