#!/bin/sh

# Set Variables 
XF86_LIB_DIR="/usr/X11R6/lib/modules"
XF86_DRV_DIR="/usr/X11R6/lib/modules/drivers"
cmd_sudo=""
test -e /usr/bin/sudo && cmd_sudo="sudo"

# Uninstall
if [ "$1" = "uninstall" ]; then
echo "ASPEED Graphics Family Linux XF86 driver uninstall begin ...."
$cmd_sudo rm -f $XF86_DRV_DIR/ast_drv.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libddc.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libfb.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libint10.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libramdac.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libvbe.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libvgahw.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libxaa.*

test -e ./backup/ast_drv.* && $cmd_sudo cp -f ./backup/ast_drv.*   $XF86_DRV_DIR
# $cmd_sudo cp -f ./backup/libddc.*    $XF86_LIB_DIR
# $cmd_sudo cp -f ./backup/libfb.*     $XF86_LIB_DIR
# $cmd_sudo cp -f ./backup/libint10.*  $XF86_LIB_DIR
# $cmd_sudo cp -f ./backup/libramdac.* $XF86_LIB_DIR
# $cmd_sudo cp -f ./backup/libvbe.*    $XF86_LIB_DIR
# $cmd_sudo cp -f ./backup/libvgahw.*  $XF86_LIB_DIR
# $cmd_sudo cp -f ./backup/libxaa.*    $XF86_LIB_DIR

$cmd_sudo rm -rf ./backup
echo "ASPEED Graphics Family Linux XF86 driver Uninstall Finished"
exit 0
fi

# Install
echo "ASPEED Graphics Family Linux XF86 driver update begin ...."
$cmd_sudo rm -rf ./backup
$cmd_sudo mkdir ./backup
test -e $XF86_DRV_DIR/ast_drv.* && $cmd_sudo cp -f $XF86_DRV_DIR/ast_drv.* ./backup
# $cmd_sudo cp -f $XF86_LIB_DIR/libddc.* ./backup
# $cmd_sudo cp -f $XF86_LIB_DIR/libfb.* ./backup
# $cmd_sudo cp -f $XF86_LIB_DIR/libint10.* ./backup
# $cmd_sudo cp -f $XF86_LIB_DIR/libramdac.* ./backup
# $cmd_sudo cp -f $XF86_LIB_DIR/libvbe.* ./backup
# $cmd_sudo cp -f $XF86_LIB_DIR/libvgahw.* ./backup
# $cmd_sudo cp -f $XF86_LIB_DIR/libxaa.* ./backup

$cmd_sudo rm -f $XF86_DRV_DIR/ast_drv.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libddc.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libfb.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libint10.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libramdac.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libvbe.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libvgahw.*
# $cmd_sudo rm -f $XF86_LIB_DIR/libxaa.*

$cmd_sudo cp -f ast_drv.*   $XF86_DRV_DIR
# $cmd_sudo cp -f libddc.*    $XF86_LIB_DIR
# $cmd_sudo cp -f libfb.*     $XF86_LIB_DIR
# $cmd_sudo cp -f libint10.*  $XF86_LIB_DIR
# $cmd_sudo cp -f libramdac.* $XF86_LIB_DIR
# $cmd_sudo cp -f libvbe.*    $XF86_LIB_DIR
# $cmd_sudo cp -f libvgahw.*  $XF86_LIB_DIR
# $cmd_sudo cp -f libxaa.*    $XF86_LIB_DIR

echo "ASPEED Graphics Family Linux XF86 driver update finished"

