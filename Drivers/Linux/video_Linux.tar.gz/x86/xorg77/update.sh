#!/bin/sh

# Set Variables 
XF86_LIB_DIR="/usr/lib/xorg/modules"
XF86_DRV_DIR="/usr/lib/xorg/modules/drivers"
cmd_sudo=""
test -e /usr/bin/sudo && cmd_sudo="sudo"

# Uninstall
if [ "$1" = "uninstall" ]; then
echo "ASPEED Graphics Family Linux XORG 7.7 driver uninstall begin ...."
$cmd_sudo rm -f $XF86_DRV_DIR/ast_drv.*

test -e ./backup/ast_drv.so && $cmd_sudo cp -f ./backup/ast_drv.*   $XF86_DRV_DIR/ast_drv.*

$cmd_sudo rm -rf ./backup
echo "ASPEED Graphics Family Linux XORG 7.7 driver Uninstall Finished"
exit 0
fi

# Install
echo "ASPEED Graphics Family Linux XORG 7.7 driver update begin ...."
$cmd_sudo rm -rf ./backup
$cmd_sudo mkdir ./backup
test -e $XF86_DRV_DIR/ast_drv.so && $cmd_sudo cp -f $XF86_DRV_DIR/ast_drv.* ./backup

$cmd_sudo rm -f $XF86_DRV_DIR/ast_drv.*

$cmd_sudo cp -f ast_drv.*   $XF86_DRV_DIR

echo "ASPEED Graphics Family Linux XORG 7.7 driver update finished"

