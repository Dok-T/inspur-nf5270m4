./fru-change_x64 -kcs BP Zhenzhu
./fru-change_x64 -kcs BM Inspur
./fru-change_x64 -kcs PN NF5270M4
./fru-change_x64 -kcs PM Inspur
./fru-change_x64 -kcs PV 01
